const mysql = require("mysql");
const config = require("./config.json");

// Creates MySQL connection using database credential provided in config.json
// Do not edit. If the connection fails, make sure to check that config.json is filled out correctly
const connection = mysql.createConnection({
  host: config.rds_host,
  user: config.rds_user,
  password: config.rds_password,
  port: config.rds_port,
  database: config.rds_db,
});
connection.connect((err) => err && console.log(err));

const author = async function (req, res) {
  // TODO (TASK 1): replace the values of name and pennKey with your own
  const name = "Tianyi Wu";
  const pennKey = "tianyiwu";

  // checks the value of type the request parameters
  // note that parameters are required and are specified in server.js in the endpoint by a colon (e.g. /author/:type)
  if (req.params.type === "name") {
    // res.send returns data back to the requester via an HTTP response
    res.send(`Created by ${name}`);
  } else if (req.params.type === "pennkey") {
    // TODO (TASK 2): edit the else if condition to check if the request parameter is 'pennkey' and if so, send back response 'Created by [pennkey]'
    res.send(`Created by ${pennKey}`);
  } else {
    // we can also send back an HTTP status code to indicate an improper request
    res
      .status(400)
      .send(
        `'${req.params.type}' is not a valid author type. Valid types are 'name' and 'pennkey'.`
      );
  }
};

const song = async function (req, res) {
  // TODO (TASK 4): implement a route that given a song_id, returns all information about the song
  // Hint: unlike route 2, you can directly SELECT * and just return data[0]
  // Most of the code is already written for you, you just need to fill in the query
  connection.query(
    `
      SELECT *
      FROM Songs
      WHERE song_id = '${req.params.song_id}'
    `,
    (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data[0]);
      }
    }
  );
};

const test = async function (req, res) {
  connection.query(
    `SELECT * FROM TENNIS.Test`, // Query string
    (err, data) => {
      // Callback function
      if (err || data.length === 0) {
        console.log(err);
        res.status(500).json({ error: "Internal Server Error" });
      } else {
        res.json(data[0]);
      }
    }
  );
};

// Route 1: Get /player_card_men/ :first_name, last_name
// Work
const player_card_man = async function (req, res) {
  connection.query(
    `
    SELECT player_id AS id, first_name, last_name, hand, birth_date AS birthday, country_id AS country, gender
    FROM Player_Men
    WHERE first_name = '${req.params.first_name}' AND last_name = '${req.params.last_name}'
    `,
    (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    }
  );
};

// Work
const player_card_woman = async function (req, res) {
  connection.query(
    `
    SELECT player_id AS id, first_name, last_name, hand, birth_date AS birthday, country_id AS country, gender
    FROM Player_Women
    WHERE first_name = '${req.params.first_name}' AND last_name = '${req.params.last_name}'
    `,
    (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    }
  );
};

// Work
const top_player_women = async function (req, res) {
  connection.query(
    `
    SELECT player_id, player_name, COUNT(*) AS matches_played
    FROM (
       SELECT winner_id AS player_id, winner_name AS player_name
       FROM Tournament_Women
       UNION ALL
       SELECT loser_id AS player_id, loser_name AS player_name
       FROM Tournament_Women
    ) AS players
    GROUP BY player_id, player_name
    ORDER BY matches_played DESC
    LIMIT ${req.params.count};
    `,
    (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    }
  );
};

// Work
const top_player_men = async function (req, res) {
  connection.query(
    `
    SELECT player_id, player_name, COUNT(*) AS matches_played
    FROM (
       SELECT winner_id AS player_id, winner_name AS player_name
       FROM Tournament_Men
       UNION ALL
       SELECT loser_id AS player_id, loser_name AS player_name
       FROM Tournament_Men
    ) AS players
    GROUP BY player_id, player_name
    ORDER BY matches_played DESC
    LIMIT ${req.params.count};
    `,
    (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    }
  );
};

// Work
const players_with_most_losses = async function (req, res) {
  const numberOfPlayers = req.params.count; // Get the number of players from request parameters

  // Ensure the input is a valid number
  if (isNaN(numberOfPlayers) || numberOfPlayers < 1) {
    res.status(400).send("Invalid number of players requested");
    return;
  }

  const query = `
    SELECT player_id, first_name, last_name, COUNT(loser_id) AS total_losses
    FROM (
      SELECT player_id, first_name, last_name, loser_id
      FROM Player_Men pm
      JOIN Tournament_Men_Qual tmq ON pm.player_id = tmq.loser_id
      UNION ALL
      SELECT player_id, first_name, last_name, loser_id
      FROM Player_Women pw
      JOIN Tournament_Women_Qual twq ON pw.player_id = twq.loser_id
    ) AS combined
    GROUP BY player_id, first_name, last_name
    ORDER BY total_losses DESC
    LIMIT ${numberOfPlayers}
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.log(err);
      res.status(500).send("Error retrieving players with most losses");
    } else {
      if (data.length === 0) {
        res.status(404).send("No data found");
      } else {
        res.json(data);
      }
    }
  });
};

// Work
const top_ranked_players = async function (req, res) {
  const numberOfPlayers = req.params.count; // Number of players
  const country = req.params.country; // Country code, e.g., 'USA'
  const date = req.params.date; // Date in YYYYMMDD format, e.g., 20000101

  const query = `
  SELECT
  p.player_id,
  p.first_name,
  p.last_name,
  p.gender,
  cr.player_rank,
  cr.ranking_points
FROM
  (SELECT player_id, first_name, last_name, country_id, 'M' AS gender FROM Player_Men
   UNION ALL
   SELECT player_id, first_name, last_name, country_id, 'W' AS gender FROM Player_Women) AS p
JOIN
  (SELECT
      player_id,
      ranking_date,
      player_rank,
      ranking_points,
      CASE
          WHEN SUBSTRING(ranking_date, 1, 4) = '2000' THEN 'Men_00'
          WHEN SUBSTRING(ranking_date, 1, 4) = '2020' THEN 'Men_20'
          -- Add similar lines for Women's rankings if needed
          WHEN SUBSTRING(ranking_date, 1, 4) = '2000' THEN 'Women_00'
          WHEN SUBSTRING(ranking_date, 1, 4) = '2020' THEN 'Women_20'
      END AS ranking_type
  FROM
      Ranking_Men_00
  UNION ALL
  SELECT
      player_id,
      ranking_date,
      player_rank,
      ranking_points,
      'Men_20' AS ranking_type
  FROM
      Ranking_Men_20
  UNION ALL
  SELECT
      player_id,
      ranking_date,
      player_rank,
      ranking_points,
      'Women_00' AS ranking_type
  FROM
      Ranking_Women_00
  UNION ALL
  SELECT
      player_id,
      ranking_date,
      player_rank,
      ranking_points,
      'Women_20' AS ranking_type
  FROM
      Ranking_Women_20) AS cr
ON p.player_id = cr.player_id
WHERE
  cr.ranking_date = ${date} AND p.country_id = '${country}'
ORDER BY
  cr.player_rank ASC
LIMIT ${numberOfPlayers};
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.log(err);
      res.status(500).send("Error retrieving top ranked players");
    } else {
      if (data.length === 0) {
        res.status(404).send("No data found");
      } else {
        res.json(data);
      }
    }
  });
};

// Work
const players_improve = async function (req, res) {
  const player_id = req.params.player_id;
  const year1 = req.params.year1;
  const year2 = req.params.year2;

  const query = `
  WITH combined_ranking AS (
    SELECT player_id, YEAR(ranking_date) AS year, player_rank
    FROM Ranking_Men_00
    UNION ALL
    SELECT player_id, YEAR(ranking_date), player_rank
    FROM Ranking_Men_20
    UNION ALL
    SELECT player_id, YEAR(ranking_date), player_rank
    FROM Ranking_Women_00
    UNION ALL
    SELECT player_id, YEAR(ranking_date), player_rank
    FROM Ranking_Women_20
  ),
  start_year AS (
    SELECT player_rank
    FROM combined_ranking
    WHERE player_id = ${player_id} AND year = ${year1}
    LIMIT 1
  ),
  last_year AS (
    SELECT player_rank
    FROM combined_ranking
    WHERE player_id = ${player_id} AND year = ${year2}
    LIMIT 1
  )
  SELECT sy.player_rank AS start_year_rank, ly.player_rank AS last_year_rank
  FROM start_year sy
  LEFT JOIN last_year ly ON 1 = 1;
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.log(err);
      res.status(500).send("Error retrieving players with most losses");
    } else {
      if (data.length === 0) {
        res.status(404).send("No data found");
      } else {
        res.json(data);
      }
    }
  });
};

// Work
const player_ranking_years = async function (req, res) {
  const year1 = req.params.year1;
  const year2 = req.params.year2;

  const query = `
    SELECT player_id, player_name, AVG(player_rank) AS avg_player_rank
  FROM (
    SELECT rm.player_id, CONCAT(pm.first_name, ' ', pm.last_name) AS player_name, rm.player_rank
    FROM Ranking_Men_00 rm
    JOIN Player_Men pm ON rm.player_id = pm.player_id
    WHERE rm.ranking_date >= ${year1} AND rm.ranking_date <= ${year2}

    UNION ALL

    SELECT rw.player_id, CONCAT(pw.first_name, ' ', pw.last_name) AS player_name, rw.player_rank
    FROM Ranking_Women_00 rw
    JOIN Player_Women pw ON rw.player_id = pw.player_id
    WHERE rw.ranking_date >= ${year1} AND rw.ranking_date <= ${year2}

    UNION ALL

    SELECT rm20.player_id, CONCAT(pm.first_name, ' ', pm.last_name) AS player_name, rm20.player_rank
    FROM Ranking_Men_20 rm20
    JOIN Player_Men pm ON rm20.player_id = pm.player_id
    WHERE rm20.ranking_date >= ${year1} AND rm20.ranking_date <= ${year2}

    UNION ALL

    SELECT rw20.player_id, CONCAT(pw.first_name, ' ', pw.last_name) AS player_name, rw20.player_rank
    FROM Ranking_Women_20 rw20
    JOIN Player_Women pw ON rw20.player_id = pw.player_id
    WHERE rw20.ranking_date >= ${year1} AND rw20.ranking_date <= ${year2}
  ) AS combined_ranks
  GROUP BY player_id, player_name
  ORDER BY avg_player_rank ASC
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.log(err);
      res.status(500).send("Error retrieving players with most losses");
    } else {
      if (data.length === 0) {
        res.status(404).send("No data found");
      } else {
        res.json(data);
      }
    }
  });
};

// Work
const best_surface = (req, res) => {
  const surface = req.params.surface; // Get the surface from request parameters

  const query = `
  WITH AllMatches AS (
    SELECT winner_id AS player_id, first_name, last_name,
           surface,
           1 AS is_winner
    FROM Tournament_Women
    JOIN Player_Women ON Tournament_Women.winner_id = Player_Women.player_id
 
    UNION ALL
 
    SELECT winner_id AS player_id, first_name, last_name,
           surface,
           1 AS is_winner
    FROM Tournament_Men
    JOIN Player_Men ON Tournament_Men.winner_id = Player_Men.player_id
 
 
    UNION ALL
 
 
    SELECT loser_id AS player_id, first_name, last_name,
           surface,
           0 AS is_winner
    FROM Tournament_Women
    JOIN Player_Women ON Tournament_Women.loser_id = Player_Women.player_id
 
    UNION ALL
 
    SELECT loser_id AS player_id, first_name, last_name,
           surface,
           0 AS is_winner
    FROM Tournament_Men
    JOIN Player_Men ON Tournament_Men.loser_id = Player_Men.player_id
 )
 
 
 SELECT player_id,
       first_name,
       last_name,
       surface AS best_surface,
       MAX(win_rate) AS max_win_rate
 FROM (
    SELECT player_id,
           first_name,
           last_name,
           surface,
           SUM(is_winner) * 100.0 / COUNT(*) AS win_rate,
           ROW_NUMBER() OVER (PARTITION BY player_id ORDER BY SUM(is_winner) * 100.0 / COUNT(*) DESC) AS rn
    FROM AllMatches
    GROUP BY player_id, first_name, last_name, surface
 ) AS player_surface_win_rates
 WHERE win_rate > 0 and surface = '${surface}'
 GROUP BY player_id, first_name, last_name;
  `;

  connection.query(query, [surface], (err, results) => {
    if (err) {
      console.error("Error executing the query", err);
      res.status(500).send("Error executing the query");
    } else {
      res.json(results);
    }
  });
};

// Work
const winning_stat = async function (req, res) {
  const player1 = req.params.player1;
  const player2 = req.params.player2;

  const query = `
  SELECT
  p1.player_id AS player1_id,
  p1.first_name AS player1_first_name,
  p1.last_name AS player1_last_name,
  p2.player_id AS player2_id,
  p2.first_name AS player2_first_name,
  p2.last_name AS player2_last_name,
  SUM(CASE WHEN t.winner_id = p1.player_id THEN 1 ELSE 0 END) AS p1_wins,
  SUM(CASE WHEN t.winner_id = p2.player_id THEN 1 ELSE 0 END) AS p2_wins,
  COUNT(*) AS total_matches,
  ROUND(SUM(CASE WHEN t.winner_id = p1.player_id THEN 1 ELSE 0 END) / COUNT(*), 2) AS p1_win_percentage,
  ROUND(SUM(CASE WHEN t.winner_id = p2.player_id THEN 1 ELSE 0 END) / COUNT(*), 2) AS p2_win_percentage
 FROM Tournament_Men t
 JOIN Player_Men p1 ON t.winner_id = p1.player_id
 JOIN Player_Men p2 ON t.loser_id = p2.player_id
 WHERE (p1.player_id = ${player1} AND p2.player_id = ${player2})
   OR (p1.player_id = ${player2} AND p2.player_id = ${player1})
 GROUP BY p1.player_id, p2.player_id, p1.first_name, p1.last_name, p2.first_name, p2.last_name;
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.log(err);
      res.status(500).send("Error retrieving top ranked players");
    } else {
      if (data.length === 0) {
        res.status(404).send("No data found");
      } else {
        res.json(data);
      }
    }
  });
};

module.exports = {
  player_card_man,
  player_card_woman,
  top_player_men,
  top_player_women,
  players_with_most_losses,
  top_ranked_players,
  players_improve,
  player_ranking_years,
  best_surface,
  winning_stat,
  test,
};
